/** Dentingan manis (latte art, hadiah kecil). */
export function playTing(ctx: AudioContext, out: AudioNode, pitch = 1): AudioScheduledSourceNode {
  const t = ctx.currentTime;
  const env = ctx.createGain();
  env.gain.setValueAtTime(0.0001, t);
  env.gain.exponentialRampToValueAtTime(0.2, t + 0.01);
  env.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
  env.connect(out);

  const main = ctx.createOscillator();
  main.type = 'sine';
  main.frequency.value = 1600 * pitch;
  const overtone = ctx.createOscillator();
  overtone.type = 'sine';
  overtone.frequency.value = 3200 * pitch;
  const overtoneGain = ctx.createGain();
  overtoneGain.gain.value = 0.3;
  main.connect(env);
  overtone.connect(overtoneGain);
  overtoneGain.connect(env);

  main.onended = () => env.disconnect();
  main.start(t);
  overtone.start(t);
  main.stop(t + 0.5);
  overtone.stop(t + 0.5);
  return main;
}

/** Kopi tumpah: noise tersaring yang meluncur turun. */
export function playSpill(ctx: AudioContext, out: AudioNode, noise: AudioBuffer | null): AudioScheduledSourceNode {
  const t = ctx.currentTime;
  const src = ctx.createBufferSource();
  if (noise) src.buffer = noise;
  src.loop = true;
  const band = ctx.createBiquadFilter();
  band.type = 'bandpass';
  band.Q.value = 1.1;
  band.frequency.setValueAtTime(2200, t);
  band.frequency.exponentialRampToValueAtTime(600, t + 0.6);
  const env = ctx.createGain();
  env.gain.setValueAtTime(0.0001, t);
  env.gain.exponentialRampToValueAtTime(0.18, t + 0.06);
  env.gain.exponentialRampToValueAtTime(0.0001, t + 0.65);
  src.connect(band);
  band.connect(env);
  env.connect(out);
  src.onended = () => env.disconnect();
  src.start(t);
  src.stop(t + 0.7);
  return src;
}
