import { useId } from "react";
import { P } from "@/core/palette";
import type { Expression } from "./Character.types";
import { AnimalMouth } from "./parts/AnimalMouth";
import { Eyes } from "./parts/Eyes";

export type FoxState = "rest" | "jump" | "shake";

interface Props {
  expression?: Expression;
  state?: FoxState;
}

/**
 * Rubah di balik semak. Ekor besarnya selalu terlihat (lucunya: "bersembunyi" tapi ekornya kelihatan).
 * Saat state "jump", seluruh badan rubah (fox-body) melompat naik dan berputar.
 */
export function Fox({ expression = "idle", state = "rest" }: Props) {
  const uid = useId().replace(/:/g, "");
  const furId = `fox${uid}`;
  const earId = `ear${uid}`;
  const fur = `url(#${furId})`;

  return (
    <svg
      className="cat-svg fox-svg"
      data-expr={expression}
      data-state={state}
      viewBox="0 0 320 300"
      aria-hidden="true"
    >
      <defs>
        <radialGradient id={furId} cx="50%" cy="35%" r="70%">
          <stop offset="0" stopColor="#fb9150" />
          <stop offset="1" stopColor="#e8742c" />
        </radialGradient>
        {/* telinga: ujung cokelat tua, sisanya oranye */}
        <linearGradient id={earId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a2f1e" />
          <stop offset="0.3" stopColor="#4a2f1e" />
          <stop offset="0.32" stopColor="#e8742c" />
          <stop offset="1" stopColor="#e8742c" />
        </linearGradient>
      </defs>

      <g className="tail">
        <path
          d="M196 236 C262 236 282 170 244 126"
          fill="none"
          stroke={fur}
          strokeWidth="46"
          strokeLinecap="round"
        />
        <circle cx="246" cy="122" r="28" fill="#fff" />
      </g>

      <g className="fox-body">
        <ellipse cx="150" cy="238" rx="56" ry="54" fill={fur} />
        <ellipse cx="150" cy="226" rx="34" ry="36" fill="#fff" />
        <ellipse cx="124" cy="284" rx="16" ry="10" fill="#4a2f1e" />
        <ellipse cx="176" cy="284" rx="16" ry="10" fill="#4a2f1e" />

        <g className="head">
          <g className="ear-l">
            <path d="M104 118 L84 48 L140 92 Z" fill={`url(#${earId})`} />
            <path d="M108 112 L96 74 L130 98 Z" fill="#fff3e0" />
          </g>
          <g className="ear-r">
            <path d="M196 118 L216 48 L160 92 Z" fill={`url(#${earId})`} />
            <path d="M192 112 L204 74 L170 98 Z" fill="#fff3e0" />
          </g>
          <ellipse cx="150" cy="140" rx="62" ry="52" fill={fur} />
          <path
            d="M96 150 Q110 176 150 178 Q190 176 204 150 Q192 190 150 194 Q108 190 96 150 Z"
            fill="#fff"
          />
          <ellipse
            cx="96"
            cy="156"
            rx="12"
            ry="7"
            fill="#ff8fa8"
            opacity=".5"
          />
          <ellipse
            cx="204"
            cy="156"
            rx="12"
            ry="7"
            fill="#ff8fa8"
            opacity=".5"
          />
          <Eyes expression={expression} lx={122} rx={178} y={134} s={0.55} />
          <ellipse cx="150" cy="154" rx="8" ry="6" fill="#3a2418" />
          <AnimalMouth expression={expression} x={150} y={158} s={0.8} />
        </g>
      </g>

      <g className="bush">
        <circle cx="64" cy="246" r="54" fill={P.matcha700} />
        <circle cx="132" cy="234" r="58" fill={P.matcha700} />
        <circle cx="204" cy="238" r="56" fill={P.matcha700} />
        <circle cx="262" cy="254" r="46" fill={P.matcha700} />
        <circle cx="160" cy="252" r="56" fill={P.matcha700} />
        <circle cx="112" cy="214" r="22" fill={P.matcha500} />
        <circle cx="190" cy="218" r="20" fill={P.matcha500} />
        <circle cx="58" cy="232" r="16" fill={P.matcha500} />
        <circle cx="252" cy="238" r="16" fill={P.matcha500} />
        <circle cx="150" cy="248" r="18" fill={P.matcha500} />
      </g>
    </svg>
  );
}
