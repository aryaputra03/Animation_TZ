import { useRef, useState } from "react";
import { SoundManager } from "@/audio/SoundManager";
import { LABELS } from "@/content/system";
import { say } from "@/core/bubbles";
import { spawnSparkles } from "@/core/fx";
import { HAPTIC, vibrate } from "@/core/haptics";
import { useTapGuard } from "@/core/hooks/useTapGuard";
import { useTimeouts } from "@/core/hooks/useTimeouts";
import { P } from "@/core/palette";
import { Rabbit } from "./Rabbit";
import { useCharacter } from "./useCharacter";

type Mode = "rest" | "hug" | "pat";

const HUG_MS = 2600;
const PAT_MS = 1300;

/**
 * Kakak kelinci dan adiknya.
 * - ketuk adik: melompat ke pelukan kakak lalu kembali
 * - ketuk kakak: telinganya bergoyang dan lengannya mengelus kepala adik
 */
export function RabbitPair() {
  const [mode, setMode] = useState<Mode>("rest");
  const big = useCharacter();
  const small = useCharacter();
  const fxRef = useRef<HTMLDivElement>(null);
  const canTap = useTapGuard();
  const { after } = useTimeouts();
  const busy = mode !== "rest";

  const run = (next: Mode, ms: number, chirpPitch: number, lineId: string) => {
    if (!canTap() || busy) return;
    setMode(next);
    big.react("happy", ms);
    small.react("happy", ms);
    SoundManager.play("rabbit.chirp", { pitch: chirpPitch });
    vibrate(HAPTIC.tap);
    spawnSparkles(fxRef.current, 3);
    say("react", { id: lineId });
    after(() => setMode("rest"), ms);
  };

  return (
    <div
      className="rabbit-stage relative mx-auto w-[min(92vw,380px)]"
      style={{ aspectRatio: "380 / 300" }}
      data-mode={mode}
    >
      <div
        ref={fxRef}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-20"
      />

      <button
        type="button"
        aria-label={LABELS.rabbitBig}
        onClick={() => run("pat", PAT_MS, 0.85, "rabbit-pat")}
        className="rabbit-big absolute right-[4%] bottom-0 block w-[50%] cursor-pointer border-0 bg-transparent p-0"
      >
        <Rabbit expression={big.override ?? "idle"} />
      </button>

      {/* lengan kakak yang mengelus kepala adik */}
      <svg
        className="pat-arm pointer-events-none absolute bottom-[40%] left-[20%] z-10 w-[36%]"
        viewBox="0 0 160 40"
        aria-hidden="true"
      >
        <rect
          x="30"
          y="8"
          width="124"
          height="24"
          rx="12"
          fill="#fffdf7"
          stroke="rgba(74,47,30,0.18)"
          strokeWidth="2.5"
        />
        <ellipse
          cx="22"
          cy="20"
          rx="20"
          ry="16"
          fill="#fffdf7"
          stroke="rgba(74,47,30,0.18)"
          strokeWidth="2.5"
        />
        <path
          d="M12 12 L12 20 M20 10 L20 20 M28 12 L28 20"
          stroke={P.coffee500}
          strokeWidth="2"
          strokeLinecap="round"
          opacity=".5"
        />
      </svg>

      <div
        className="rabbit-adik absolute bottom-0 left-[6%] z-[15] w-[30%]"
        data-hug={mode === "hug"}
        data-pat={mode === "pat"}
      >
        <button
          type="button"
          aria-label={LABELS.rabbitSmall}
          onClick={() => run("hug", HUG_MS, 1.3, "rabbit-hug")}
          className="block w-full cursor-pointer border-0 bg-transparent p-0"
        >
          <Rabbit scarf expression={small.override ?? "idle"} />
        </button>
      </div>
    </div>
  );
}
