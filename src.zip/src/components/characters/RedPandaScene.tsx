import { useEffect, useRef, useState } from "react";
import { SoundManager } from "@/audio/SoundManager";
import { LABELS } from "@/content/system";
import { say } from "@/core/bubbles";
import { spawnSparkles } from "@/core/fx";
import { HAPTIC, vibrate } from "@/core/haptics";
import { useTapGuard } from "@/core/hooks/useTapGuard";
import { useTimeouts } from "@/core/hooks/useTimeouts";
import type { Expression } from "./Character.types";
import { RedPanda } from "./RedPanda";
import { useCharacter } from "./useCharacter";

const AWAKE_MS = 8000;
const ROLL_MS = 1500;

/**
 * Red panda yang mengantuk. Ketuk: terbangun kaget, menguap, berguling pelan sambil memeluk
 * bambu, lalu setelah sekitar 8 detik diam ia tertidur lagi.
 */
export function RedPandaScene() {
  const [awake, setAwake] = useState(false);
  const [rolling, setRolling] = useState(false);
  const { override, react } = useCharacter();
  const fxRef = useRef<HTMLDivElement>(null);
  const sleepTimer = useRef(0);
  const canTap = useTapGuard();
  const { after, cancel } = useTimeouts();

  useEffect(() => () => window.clearTimeout(sleepTimer.current), []);

  const wake = () => {
    if (!canTap()) return;
    SoundManager.play("redpanda.twitter");
    SoundManager.play("redpanda.yawn", { delay: 0.5 });
    vibrate(HAPTIC.tap);
    spawnSparkles(fxRef.current, 3);
    say("react", { id: "panda-wake" });

    setAwake(true);
    setRolling(true);
    react("surprised", 500);
    after(() => react("happy", 900), 500); // menguap
    after(() => setRolling(false), ROLL_MS);

    cancel(sleepTimer.current);
    sleepTimer.current = after(() => setAwake(false), AWAKE_MS);
  };

  const shown: Expression = override ?? (awake ? "idle" : "sleepy");

  return (
    <div
      className="relative mx-auto w-[min(72vw,290px)]"
      style={{ aspectRatio: "220 / 260" }}
    >
      <div
        ref={fxRef}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-10"
      />
      <button
        type="button"
        aria-label={LABELS.redPanda}
        onClick={wake}
        className="block h-full w-full cursor-pointer border-0 bg-transparent p-0"
      >
        <RedPanda expression={shown} rolling={rolling} />
      </button>
    </div>
  );
}
