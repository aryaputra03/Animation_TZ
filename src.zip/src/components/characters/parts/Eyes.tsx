import { P } from '@/core/palette';
import type { Expression } from '../Character.types';

const INK = '#2b1a2e';

interface EyeProps {
  expression: Expression;
  x: number;
  y: number;
  s: number;
}

function Eye({ expression, x, y, s }: EyeProps) {
  const t = `translate(${x} ${y}) scale(${s})`;
  switch (expression) {
    case 'happy':
    case 'cheer':
    case 'purr':
      return <path transform={t} d="M-22 7 Q0 -22 22 7" fill="none" stroke={INK} strokeWidth="7" strokeLinecap="round" />;
    case 'sleepy':
      return <path transform={t} d="M-22 -2 Q0 16 22 -2" fill="none" stroke={INK} strokeWidth="7" strokeLinecap="round" />;
    case 'love':
      return <path transform={t} d="M0 18 C-36 -6 -26 -34 0 -14 C26 -34 36 -6 0 18Z" fill="#ff5d8f" />;
    case 'lebay':
      return (
        <polygon
          transform={t}
          points="0,-30 8,-10 30,-10 12,4 18,26 0,13 -18,26 -12,4 -30,-10 -8,-10"
          fill={P.sun400}
        />
      );
    case 'surprised':
      return (
        <g transform={t}>
          <ellipse rx="29" ry="34" fill={INK} />
          <circle cx="-10" cy="-14" r="12" fill="#fff" />
          <circle cx="11" cy="16" r="5" fill="#fff" />
        </g>
      );
    default:
      return (
        <g transform={t}>
          <ellipse rx="26" ry="30" fill={INK} />
          <g className="glint">
            <circle cx="-9" cy="-12" r="10" fill="#fff" />
          </g>
          <circle cx="10" cy="14" r="5" fill="#fff" />
          <circle cx="6" cy="-24" r="3" fill="#bfe9ff" />
        </g>
      );
  }
}

interface EyesProps {
  expression: Expression;
  /** Posisi tengah mata kiri dan kanan (satuan viewBox). */
  lx: number;
  rx: number;
  y: number;
  /** Skala ukuran mata, bawaan 1. */
  s?: number;
}

/** Mata bergaya sama untuk semua hewan. Hanya mata terbuka (idle) yang berkedip. */
export function Eyes({ expression, lx, rx, y, s = 1 }: EyesProps) {
  return (
    <g className={expression === 'idle' ? 'blink' : undefined}>
      <Eye expression={expression} x={lx} y={y} s={s} />
      <Eye expression={expression} x={rx} y={y} s={s} />
    </g>
  );
}
