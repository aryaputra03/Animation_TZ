import { useLayoutEffect, useRef } from 'react';
import { gsap, ScrollTrigger } from '@/core/gsap';

const COUNT = 9;

/** Jejak kaki di tepi kanan yang terisi mengikuti progres scroll. Tanpa render ulang React. */
export function PawProgress() {
  const boxRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const box = boxRef.current;
    const scrollRoot = document.getElementById('scroll-root');
    if (!box || !scrollRoot) return;

    const paws = Array.from(box.children) as SVGElement[];
    let last = -1;
    const apply = (progress: number) => {
      const filled = Math.round(progress * COUNT);
      if (filled === last) return;
      last = filled;
      paws.forEach((el, i) => {
        el.dataset.on = String(i < filled);
      });
    };

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: scrollRoot,
        start: 'top top',
        end: 'bottom bottom',
        onUpdate: (self) => apply(self.progress),
        onRefresh: (self) => apply(self.progress),
      });
    });
    return () => ctx.revert();
  }, []);

  return (
    <div
      ref={boxRef}
      aria-hidden="true"
      className="pointer-events-none fixed top-1/2 z-50 flex -translate-y-1/2 flex-col gap-2"
      style={{ right: 'calc(env(safe-area-inset-right, 0px) + 6px)' }}
    >
      {Array.from({ length: COUNT }, (_, i) => (
        <svg
          key={i}
          className="paw"
          data-on="false"
          viewBox="0 0 24 24"
          width="22"
          height="22"
          style={{ rotate: i % 2 === 0 ? '-12deg' : '12deg' }}
        >
          <ellipse cx="12" cy="16.5" rx="5.2" ry="4.2" />
          <circle cx="5.5" cy="10.5" r="2.3" />
          <circle cx="9.5" cy="6.5" r="2.3" />
          <circle cx="14.5" cy="6.5" r="2.3" />
          <circle cx="18.5" cy="10.5" r="2.3" />
        </svg>
      ))}
    </div>
  );
}
