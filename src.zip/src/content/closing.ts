/** Penutup: pesan dari pengirim dan konfigurasi tombol WhatsApp. */

// TODO: PESAN_PENUTUP — ditulis sendiri oleh pemilik proyek. JANGAN dikarang.
export const CLOSING_MESSAGE = 'TODO: PESAN_PENUTUP';

export const WA_NUMBER = '6289503687908';
export const WA_TEXT = 'Kakkk mau hangoutt';
export const CLOSING_BUTTON = 'Hangout bareng lagi yuk';

export const waUrl = (): string => `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(WA_TEXT)}`;
